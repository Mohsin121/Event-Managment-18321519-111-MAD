package com.practice.practicesession1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;


import android.content.Context;
import android.content.Intent;

import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity{
    ListView lvevents;
    ArrayList<eventlist> list;
    TextView display;
    Button ebtn,viewbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvevents = (ListView) findViewById(R.id.lvevents);
        display = (TextView) findViewById(R.id.display);
        ebtn = (Button) findViewById(R.id.ebtn);

        list = new ArrayList<eventlist>();

        eventlist item1 = new eventlist("Naat Competetion",
                "The Naat Compition held under the Team of UOG Islamic Society",
                "24,FEb,2021 / 9:am", "naat");
        eventlist item2 = new eventlist("TEDx Talks",
                "The Naat Compition held under the Team of UOG Islamic Society",
                "25,FEb,2021 / 10:am", "tedx");
        eventlist item3 = new eventlist("Quiz Compitition",
                "The Naat Compition held under the Team of UOG Islamic Society",
                "26,FEb,2021 / 1:pm", "quiz");
        eventlist item4 = new eventlist("Singing Competetion",
                "The Naat Compition held under the Team of UOG Islamic Society",
                "27,FEb,2021 / 11:am", "singing");
        list.add(item1);
        list.add(item2);
        list.add(item3);
        list.add(item4);

        item_adapter adapter = new item_adapter(this, list);
        lvevents.setAdapter(adapter);

        lvevents.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                view.setBackgroundColor(getColor(R.color.teal_700 )) ;
                if (position == 0) {
                    String s = list.get(position).getTitle();
                    display.setText(s);
                    selectedItem(s);
                } else if (position == 1) {
                    String s = list.get(position).getTitle();
                    display.setText(s);
                    selectedItem(s);
                } else if (position == 2) {
                    String s = list.get(position).getTitle();
                    display.setText(s);
                    selectedItem(s);
                } else {
                    String s = list.get(position).getTitle();
                    display.setText(s);
                    selectedItem(s);
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
getMenuInflater().inflate(R.menu.menu,menu);
   return true; //super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.regmenu:
                       Intent i= new Intent(this,MainActivity2.class);
                      startActivity(i);
            break;


            case R.id.exitmenu:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    void selectedItem(String z) {
        ebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(MainActivity.this, MainActivity2.class);
                i.putExtra("check", z);
                startActivity(i);
            }

        });
    }
}