  package com.practice.practicesession1;

public class eventlist {
    private String title;
    private String description;
    private String schedule;

    private String type;

    public eventlist(String title, String description, String schedule, String type) {
        this.title = title;
        this.description = description;
        this.schedule = schedule;
        this.type=type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }
    public String toString() {
        return title + ',' + description  + ',' + schedule;

    }




}
