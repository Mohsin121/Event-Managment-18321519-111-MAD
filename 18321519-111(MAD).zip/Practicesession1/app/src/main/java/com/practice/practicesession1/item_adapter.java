package com.practice.practicesession1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class item_adapter  extends ArrayAdapter<eventlist> {

    private final Context context;
    private final ArrayList<eventlist> values;

    public item_adapter(@NonNull Context context, ArrayList<eventlist> list) {
        super(context, R.layout.row_items, list);
        this.context = context;
        this.values = list;


    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.row_items, parent, false);

        TextView etitle = (TextView) view.findViewById(R.id.etitle);
        TextView edescription = (TextView) view.findViewById(R.id.edescription);
        TextView eschedule = (TextView) view.findViewById(R.id.eschedule);
        ImageView eimage = (ImageView) view.findViewById(R.id.eimage);

        etitle.setText(values.get(position).getTitle());
        edescription.setText(values.get(position).getDescription());
        eschedule.setText(values.get(position).getSchedule());
        if (values.get(position).getType().equals("naat")) {
            eimage.setImageResource(R.drawable.naat);
        }
        else if (values.get(position).getType().equals("tedx")) {
            eimage.setImageResource(R.drawable.tedx);
        }
        else if (values.get(position).getType().equals("singing")) {
            eimage.setImageResource(R.drawable.singing);
        }
        else if (values.get(position).getType().equals("quiz")) {
            eimage.setImageResource(R.drawable.quiz);
        }
        else {
            eimage.setImageResource(R.drawable.sports);
            }
            return view;
        }
    }
