package com.practice.practicesession1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    Button rebtn;
    EditText name;
    EditText roll;
    EditText dep;
    EditText hall,sect;
    Spinner spn;
    Button showbtn;
   Button fbtn;
    String rec = "";
    TextView eventfor;
    String sItem;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        rebtn = findViewById(R.id.rebtn);
        name =  findViewById(R.id.name);
        roll =  findViewById(R.id.roll);
        dep = findViewById(R.id.dep);
        hall =  findViewById(R.id.hall);
        eventfor = findViewById(R.id.eventfor);

        rec = getIntent().getStringExtra("check");
        String f = rec;
        eventfor.setText("Register for Event " + f);
        fbtn = findViewById(R.id.fbtn);
        Spinner myspinner = (Spinner) findViewById(R.id.sec);


        ArrayAdapter arrayAdapter = new ArrayAdapter<String>(MainActivity2.this,
                android.R.layout.simple_dropdown_item_1line, getResources().
                getStringArray(R.array.names));
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        myspinner.setAdapter(arrayAdapter);

        sItem = myspinner.getSelectedItem().toString();


        rebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                processinsert(name.getText().toString(),roll.getText().toString(),dep.getText().toString(),sItem,hall.getText().toString());

            }

        });

        fbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),FetchDataActivity.class));

            }
        });

    }
    private void processinsert(String n, String r, String d, String s, String h)
    {
        String res=new DBHelper(this).addrecord(n,r,d,s,h);
        name.setText("");
        roll.setText("");
        dep.setText("");
        hall.setText("");
        Toast.makeText(getApplicationContext(),res,Toast.LENGTH_SHORT).show();
    }
}

