package com.practice.practicesession1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Fetchadapter extends RecyclerView.Adapter<Fetchadapter.myviewholder> {
    ArrayList<Participants> dataholder;
    public Fetchadapter(ArrayList<Participants> dataholder) {
        this.dataholder = dataholder;
    }


    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerowforfetching,parent,false);
        return new myviewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myviewholder holder, int position) {
        holder.disname.setText(dataholder.get(position).getName());
        holder.disdroll.setText(dataholder.get(position).getRoll());
        holder.disdep.setText(dataholder.get(position).getDep());
        holder.dissec.setText(dataholder.get(position).getSec());
        holder.dishall.setText(dataholder.get(position).getHall());

    }

    @Override
    public int getItemCount() {
        return dataholder.size();
    }

    public class myviewholder extends RecyclerView.ViewHolder{
        TextView disname,disdroll,disdep,dissec,dishall;
        public myviewholder(@NonNull View itemView) {
            super(itemView);
            disname=(TextView)itemView.findViewById(R.id.displayname);
            disdroll=(TextView)itemView.findViewById(R.id.displayroll);
            disdep=(TextView)itemView.findViewById(R.id.displaydep);
            dissec=(TextView)itemView.findViewById(R.id.displaysec);
            dishall=(TextView)itemView.findViewById(R.id.displayhall);
        }
    }
}
