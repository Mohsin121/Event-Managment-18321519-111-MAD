package com.practice.practicesession1;

import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FetchDataActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<Participants> dataholder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fetchdataactivity);


        recyclerView = (RecyclerView) findViewById(R.id.recview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Cursor cursor = new DBHelper(this).readalldata();
        dataholder = new ArrayList<>();

        while (cursor.moveToNext()) {
            Participants obj = new Participants(cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5));
            dataholder.add(obj);
        }

        Fetchadapter adapter = new Fetchadapter(dataholder);
        recyclerView.setAdapter(adapter);

    }
}

