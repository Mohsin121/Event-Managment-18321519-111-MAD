package com.practice.practicesession1;

public class Participants {
    String name;
    String roll;
    String dep;
    String sec;
    String hall;


    public Participants(String name, String roll, String dep, String sec, String hall) {
        this.name = name;
        this.roll = roll;
        this.dep = dep;
        this.sec = sec;
        this.hall = hall;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRoll() {
        return roll;
    }

    public void setRoll(String roll) {
        this.roll = roll;
    }

    public String getDep() {
        return dep;
    }

    public void setDep(String dep) {
        this.dep = dep;
    }

    public String getSec() {
        return sec;
    }

    public void setSec(String sec) {
        this.sec = sec;
    }

    public String getHall() {
        return hall;
    }

    public void setHall(String hall) {
        this.hall = hall;
    }


}